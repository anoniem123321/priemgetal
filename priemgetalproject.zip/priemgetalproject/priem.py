import random
import time
import os
import sys

sys.setrecursionlimit(1000000)
def clearConsole():
    command = 'clear'
    if os.name in ('nt', 'dos'):
        command = 'cls'
    os.system(command)

clearoutput = open('output.txt', 'r+')
clearoutput.truncate(0)
clearoutput.close()

cleargetallen = open('getallen.txt', 'r+')
cleargetallen.truncate(0)
cleargetallen.close()

lijstalgemaakt = input("Heb je de getallen.txt al aangevuld? Ja/Nee\n")
clearConsole()
if lijstalgemaakt == "Nee":
    aantalcijfers = input("Hoeveel getallen wil je genereren?\n")
    clearConsole()
    print(aantalcijfers + " cijfers worden nu gemaakt!")
    time.sleep(1)
    for i in range(1, int(aantalcijfers) + 1):
        print(str(i) + " Made by Rukbunker Hogere Macht!")
        with open('getallen.txt', 'a') as file:

            print(i, file=file)
    time.sleep(3)
    clearConsole()
    print(str(aantalcijfers) + " cijfers zijn gemaakt!")
    time.sleep(5)
    clearConsole()
    priem = input("Wil je deze getallen controleren op priemgetallen? Ja/Nee\n")
    if priem == "Nee":
        exit()

def load_words(WORDLIST_FILENAME):

       clearConsole()

       print("Deze tool is gemaakt door Rukbunker Hogere Macht!")
       time.sleep(3)
       print("Getallen aan het laden...")
       wordlist = list()
       with open(WORDLIST_FILENAME) as f:
            for line in f:
                wordlist.append(line.rstrip('\n'))
       time.sleep(3)
       print(" ", len(wordlist), "getal(len) ingeladen.")
       time.sleep(4)
       clearConsole()
       return wordlist

def choose_word (wordlist):
       return random.choice(wordlist)
wordlist = load_words('getallen.txt')
def priemchecker():
    num = int(choose_word(wordlist))

    flag = False

    if num > 1:
        for i in range(2, num):
            if (num % i) == 0:
                flag = True
                break

    if flag:
        time.sleep(0.10)
        priemchecker()
    else:
        print(num, "is een priemgetal")
        time.sleep(0.10)
        with open('output.txt', 'a') as file:
            print(num, file=file)
        priemchecker()
priemchecker()